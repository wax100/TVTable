<?php
$_lang['tvtable_prop_classname'] = 'Класс таблицы';
$_lang['tvtable_prop_resource'] = 'ID ресурса (по умолчанию берется текущий)';
$_lang['tvtable_prop_tdTpl'] = "Чанк &lt;td&gt;";
$_lang['tvtable_prop_thTpl'] = 'Чанк &lt;th&gt;';
$_lang['tvtable_prop_trTpl'] ='Чанк &lt;tr&gt;';
$_lang['tvtable_prop_tv'] = 'ID TV параметра';
$_lang['tvtable_prop_wrapperTpl'] = 'Чанк-обертка таблицы';
