<?php
$_lang['classname'] = 'Класс таблицы';
$_lang['tv'] = 'ID TV параметра';
$_lang['tvtable.del_column'] = 'Удалить столбик';
$_lang['tvtable.add_row'] = 'Добавить строку';
$_lang['tvtable.del_row'] = 'Удалить строку';