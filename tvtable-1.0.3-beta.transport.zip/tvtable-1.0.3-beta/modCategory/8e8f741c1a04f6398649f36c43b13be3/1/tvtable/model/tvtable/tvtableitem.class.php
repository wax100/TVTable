<?php

/**
 * @package tvtable
 */
class TVTableItem extends xPDOSimpleObject
{
}