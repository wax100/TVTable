<?php

$_lang['tvtable_prop_limit'] = 'The number of Items to limit per page.';