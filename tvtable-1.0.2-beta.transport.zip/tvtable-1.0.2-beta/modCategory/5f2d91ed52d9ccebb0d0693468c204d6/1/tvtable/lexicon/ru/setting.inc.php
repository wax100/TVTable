<?php

$_lang['area_tvtable_main'] = 'Основные';