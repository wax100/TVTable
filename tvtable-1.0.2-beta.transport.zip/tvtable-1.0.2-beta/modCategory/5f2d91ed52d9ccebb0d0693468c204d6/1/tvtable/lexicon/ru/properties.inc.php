<?php

$_lang['tvtable_prop_limit'] = 'Ограничение вывода строк.';