<?php

$_lang['area_tvtable_main'] = 'Основные настройки';
$_lang['setting_tvtable_clear_button'] = 'Отображать кнопку очистки таблицы';
$_lang['setting_tvtable_clear_button_desc'] = 'Если выбрать "Да", то рядом с каждой таблицей будет отображаться кнопка для очистки таблицы. По умолчанию выключено.';