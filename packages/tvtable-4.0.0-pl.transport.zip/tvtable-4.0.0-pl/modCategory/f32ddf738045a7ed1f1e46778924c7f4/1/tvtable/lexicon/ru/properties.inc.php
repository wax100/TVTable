<?php

$_lang['tvtable_prop_classname'] = 'CSS класс таблицы';
$_lang['tvtable_prop_id'] = 'ID ресурса. Если не указан, используется id текущего документа';
$_lang['tvtable_prop_tdTpl'] = "Чанк &lt;td&gt;";
$_lang['tvtable_prop_thTpl'] = 'Чанк &lt;th&gt;';
$_lang['tvtable_prop_trTpl'] ='Чанк &lt;tr&gt;';
$_lang['tvtable_prop_tv'] = 'ID или название TV параметра';
$_lang['tvtable_prop_wrapperTpl'] = 'Чанк-обертка таблицы';
$_lang['tvtable_prop_bodyClass'] = 'CSS класс тега &lt;tbody&gt;';
$_lang['tvtable_prop_tableClass'] = 'CSS класс таблицы';
$_lang['tvtable_prop_headClass'] = 'CSS класс тега &lt;thead&gt;';
$_lang['tvtable_prop_head'] = 'Вывод таблицы с &lt;thead&gt;';
$_lang['tvtable_prop_getY'] = 'Вывод столбца по индексу. Также можно указывать <strong>first</strong> и <strong>last</strong>';
$_lang['tvtable_prop_getX'] = 'Вывод строки по индексу. Также можно указывать <strong>first</strong> и <strong>last</strong>';