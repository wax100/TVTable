<?php
$_lang['tvtable'] = 'TVTable';
$_lang['tvtable.add_column'] = 'Добавить столбик';
$_lang['tvtable.del_column'] = 'Удалить столбик';
$_lang['tvtable.add_row'] = 'Добавить строку';
$_lang['tvtable.del_row'] = 'Удалить строку';