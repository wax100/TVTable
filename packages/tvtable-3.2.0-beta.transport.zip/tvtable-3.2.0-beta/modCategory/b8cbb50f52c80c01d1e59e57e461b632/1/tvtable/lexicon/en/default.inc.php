<?php

$_lang['tvtable'] = 'TVTable';
$_lang['tvtable.add_column'] = 'Add column';
$_lang['tvtable.del_column'] = 'Remove column';
$_lang['tvtable.add_row'] = 'Add row';
$_lang['tvtable.del_row'] = 'Remove row';
$_lang['tvtable.clear_table'] = 'Clear table';
$_lang['tvtable.clear_table_confirm'] = 'Are you sure want to clear table values?';