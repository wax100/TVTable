<?php

$_lang['area_tvtable_main'] = 'Main settings';
$_lang['setting_tvtable_clear_button'] = 'Show clearing table button';
$_lang['setting_tvtable_clear_button_desc'] = 'Display the clearing table button.';