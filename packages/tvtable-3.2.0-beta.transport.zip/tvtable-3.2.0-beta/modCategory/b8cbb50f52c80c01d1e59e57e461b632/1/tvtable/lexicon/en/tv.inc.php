<?php

$_lang['tvtable.columns'] = 'Number of columns';
$_lang['tvtable.columns_desc'] = '<em>Note: Has priority over the <strong>Maximum number of columns</strong> property. Existing values will not be changed.</em>';
$_lang['tvtable.max_columns'] = 'Maximum number of columns';
$_lang['tvtable.max_columns_desc'] = 'Existing values will not be changed.</em>';
$_lang['tvtable.max_rows'] = 'Maximum number of rows';
$_lang['tvtable.max_rows_desc'] = 'Existing values will not be changed.</em>';