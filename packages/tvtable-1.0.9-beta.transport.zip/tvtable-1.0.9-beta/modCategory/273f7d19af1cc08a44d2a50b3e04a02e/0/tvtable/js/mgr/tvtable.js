function TVT(id) {
    this.fid = id;
    TVTable.utils.init(id);
}

var TVTable = {
    utils: {
        _insertAfter: function (elem, refElem) {
            var parent = refElem.parentNode;
            var next = refElem.nextSibling;
            if (next) {
              return parent.insertBefore(elem, next);
            } else {
              return parent.appendChild(elem);
            }
        },
        init: function(fid) {
            var field = document.getElementById(fid);
            var fldval = field.value;
            var tvtArr = fldval ? Ext.util.JSON.decode(fldval) : [["",""], ["",""]];
            field.style.display = 'none';

            TVTable.utils.addHeader(tvtArr[0], field);
            for (var row = 1; row < tvtArr.length; row++) {
                TVTable.utils.addItem(tvtArr[row], null, fid);
            }
        },
        addHeader: function(values, field){
            var rowDiv = document.createElement('div');
            rowDiv.className = 'tvtrow header';

            var box = field.nextSibling;
            while(box && box.nodeType != 1) {
                box = box.nextSibling
            }
            box.appendChild(rowDiv);

            if (!values) values = ['',''];

            for (var i = 0; i < values.length; i++) {
                rowDiv.appendChild(TVTable.utils.build(values[i]));
            }
            var add = document.createElement('input');
            add.setAttribute('type', 'button');
            add.value = '\uF054';
            add.setAttribute('title', _('tvtable.add_column'));
            add.className = 'add x-btn x-btn-small';

            rowDiv.appendChild(add);

            var del = document.createElement('input');
            del.setAttribute('type', 'button');
            del.value = '\uf053';
            del.setAttribute('title', _('tvtable.del_column'));
            del.className = 'del x-btn x-btn-small';

            rowDiv.appendChild(del);
        },
        build: function(val) {
            var field = document.createElement('input');
            field.setAttribute('type', 'text');
            field.className = 'x-form-text x-form-field';
            field.value = val;

            return field;
        },
        addItem: function(values, elem, fidd){
            var rowDiv = document.createElement('div');
            rowDiv.className = 'tvtrow';
            rowDiv.style.whiteSpace = 'nowrap';
            rowDiv.style.padding = '5px 0';

            var field = document.getElementById(fidd);
            var next = field.nextSibling;

            while (next && next.nodeType != 1) {
                next = next.nextSibling;
            }

            if (elem) {
                TVTable.utils._insertAfter(rowDiv, elem);
            } else {
                next.appendChild(rowDiv);
            }
            
            if (typeof values == 'number') {
                for (var i = 0; i < values; i++) {
                    rowDiv.appendChild(TVTable.utils.build(''));
                }
            } else {
                for (var i = 0; i < values.length; i++) {
                    rowDiv.appendChild(TVTable.utils.build((values) ? values[i] : ''));
                }
            }

            var button = document.createElement('input');
            button.setAttribute('type', 'button');
            button.value = '\uf078';
            button.setAttribute('title', _('tvtable.add_row'));
            button.className = 'add_item x-btn x-btn-small';

            rowDiv.appendChild(button);
            
            if (next.querySelectorAll('.tvtrow').length > 2) {
                var del = document.createElement('input');
                del.setAttribute('type', 'button');
                del.value = '\uf077';
                del.setAttribute('title', _('tvtable.del_row'));
                del.className = 'del_item x-btn x-btn-small';

                rowDiv.appendChild(del);
            }
        },
        checkArray: function(array) {
            if (!Ext.isArray(array)) return false;

            var values = 0;
            array.forEach(function(item, i, array) {
                if (Ext.isArray(array)) {
                    item.forEach(function(item, i, array) {
                        if (item !== '') {
                            values++;
                        }
                    });
                }
            });
            
            return values > 0 ? true : false;
        },
        setEditor: function(fid){
            var tvtArr = new Array();

            var field = document.getElementById(fid);
            var next = field.nextSibling;

            while (next && next.nodeType != 1) {
                next = next.nextSibling;
            }
            var rows = next.querySelectorAll('.tvtrow');

            for (var x = 0; x < rows.length; x++) {
                var itemsArr = new Array();
                var inputs = rows[x].querySelectorAll('input[type="text"]');

                for (var y = 0; y < inputs.length; y++) {
                    var item = inputs[y];
                    itemsArr.push(item.value);
                }

                tvtArr.push(itemsArr);
            }

            if (TVTable.utils.checkArray(tvtArr)) {
                var value = JSON.stringify(tvtArr);
                field.value = value;
            } else {
                field.value = '';
            }

            MODx.fireResourceFormChange();
        }
    }
}

document.onkeyup = function (e) {
    if (e.target.type == 'text') {
        var prev = e.target.closest('.tvtEditor').previousSibling;
        while (prev && prev.nodeType != 1) {
            prev = prev.previousSibling;
        }
        TVTable.utils.setEditor(prev.id);
    }
}

document.onclick = function (e) {
    // Add row
    if (e.target.classList.contains('add_item')) {
        var parent = e.target.parentNode;
        var length = parent.querySelectorAll('input[type="text"]').length;
        var input = e.target.closest('.tvtEditor').previousSibling;
    
        while (input && input.nodeType != 1) {
            input = input.previousSibling;
        }
    
        TVTable.utils.addItem(length, parent, input.id);
        TVTable.utils.setEditor(input.id);
    }
    // Remove row
    if (e.target.classList.contains('del_item')) {
        var prev = e.target.closest('.tvtEditor').previousSibling;
        var parent = e.target.parentNode;
        while (prev && prev.nodeType != 1) {
            prev = prev.previousSibling;
        }

        parent.remove();
        TVTable.utils.setEditor(prev.id);
    }
    // delete column
    if (e.target.classList.contains('del')) {
        var prev = e.target.closest('.tvtEditor').previousSibling;
        while (prev && prev.nodeType != 1) {
            prev = prev.previousSibling;
        }

        var parent = e.target.parentNode;
        var length = parent.querySelectorAll('input[type="text"]').length;

        var next = prev.nextSibling;
        while (next && next.nodeType != 1) {
            next = next.nextSibling;
        }

        var rows = next.querySelectorAll('.tvtrow');

        if (length > 2) {
            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                var inputs = row.querySelectorAll('input[type=text]');

                inputs[inputs.length - 1].remove();
            }
            TVTable.utils.setEditor(prev.id);
        }
    }
    // add column
    if (e.target.classList.contains('add')) {
        var prev = e.target.closest('.tvtEditor').previousSibling;
        while (prev && prev.nodeType != 1) {
            prev = prev.previousSibling;
        }

        var parent = e.target.parentNode;
        var length = parent.querySelectorAll('input[type="text"]').length;

        var next = prev.nextSibling;
        while (next && next.nodeType != 1) {
            next = next.nextSibling;
        }

        var rows = next.querySelectorAll('.tvtrow');

        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            var inputs = row.querySelectorAll('input[type=text]');

            TVTable.utils._insertAfter(TVTable.utils.build(''), inputs[inputs.length - 1])
        }
        TVTable.utils.setEditor(prev.id);
    }
}