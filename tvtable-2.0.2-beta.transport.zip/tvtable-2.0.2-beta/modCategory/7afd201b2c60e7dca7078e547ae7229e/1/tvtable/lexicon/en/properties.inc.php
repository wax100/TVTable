<?php
$_lang['tvtable_prop_classname'] = 'Table class';
$_lang['tvtable_prop_resource'] = 'Resource ID (current is default)';
$_lang['tvtable_prop_tdTpl'] = "Chunk &lt;td&gt;";
$_lang['tvtable_prop_thTpl'] = 'Chunk &lt;th&gt;';
$_lang['tvtable_prop_trTpl'] ='Chunk &lt;tr&gt;';
$_lang['tvtable_prop_tv'] = 'TV-parameter ID';
$_lang['tvtable_prop_wrapperTpl'] = 'Wrapper table chunk';
